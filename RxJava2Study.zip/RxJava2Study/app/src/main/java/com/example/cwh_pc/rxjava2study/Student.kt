package com.example.cwh_pc.rxjava2study

data class Student(var name: String, var age: Int)

