package com.example.cwh_pc.rxjava2study

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.helper.ItemTouchHelper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_recyler_view.*
import java.util.*

class RecylerViewActivity : AppCompatActivity() {
    var context:Context?=null
    var arrays=ArrayList<String>()
    lateinit var adapter:MyAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recyler_view)
        context=applicationContext
        for(i in 0 until 10){
            arrays.add("Position is $i")
        }
        mRecylerView.layoutManager=LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
        adapter=MyAdapter()
        mRecylerView.adapter=adapter

        initDrags()
    }

    private fun initDrags() {
        val callback=object :ItemTouchHelper.Callback(){


            override fun getMovementFlags(recyclerView: RecyclerView?, viewHolder: RecyclerView.ViewHolder?): Int {
                val dragFlag = ItemTouchHelper.LEFT or ItemTouchHelper.DOWN or ItemTouchHelper.UP or ItemTouchHelper.RIGHT
                val swipeFlag = ItemTouchHelper.START or ItemTouchHelper.END

                return makeMovementFlags(dragFlag,swipeFlag)
            }

            override fun isItemViewSwipeEnabled(): Boolean {
                return true
            }

            override fun isLongPressDragEnabled(): Boolean {
                return super.isLongPressDragEnabled()
            }




            override fun onMove(recyclerView: RecyclerView?, viewHolder: RecyclerView.ViewHolder?, target: RecyclerView.ViewHolder?): Boolean {
                Collections.swap(arrays,viewHolder?.adapterPosition ?:0,target?.adapterPosition ?:0)
                recyclerView?.adapter?.notifyItemMoved(viewHolder?.adapterPosition ?:0,target?.adapterPosition ?:0)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder?, direction: Int) {
                arrays.removeAt(viewHolder?.adapterPosition ?:0)
                adapter.notifyItemRemoved(viewHolder?.adapterPosition ?:0)
            }

            override fun onSelectedChanged(viewHolder: RecyclerView.ViewHolder?, actionState: Int) {
                super.onSelectedChanged(viewHolder, actionState)
                if(actionState!=ItemTouchHelper.ACTION_STATE_IDLE){
                    viewHolder?.itemView?.setBackgroundColor(Color.GRAY)
                }
            }

            override fun onChildDraw(c: Canvas?, recyclerView: RecyclerView?, viewHolder: RecyclerView.ViewHolder?, dX: Float, dY: Float, actionState: Int, isCurrentlyActive: Boolean) {
                if(actionState==ItemTouchHelper.ACTION_STATE_SWIPE){
                    val viewGroup=viewHolder?.itemView as? ViewGroup
                    val view=viewGroup?.getChildAt(1)
                    val width=view?.layoutParams?.width ?:0
                    if(Math.abs(dX)<=width){
                        viewHolder?.itemView?.scrollTo(-dX.toInt(),0)
                    }
                }else{
                    super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
                }
            }

            override fun clearView(recyclerView: RecyclerView?, viewHolder: RecyclerView.ViewHolder?) {
                super.clearView(recyclerView, viewHolder)
                viewHolder?.itemView?.setBackgroundColor(0)
                viewHolder?.itemView?.scrollX=0
            }

        }

        val itemTouchHelper=ItemTouchHelper(callback)
        itemTouchHelper.attachToRecyclerView(mRecylerView)
    }


    inner class MyAdapter:RecyclerView.Adapter<RecyclerView.ViewHolder>(){
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val view=LayoutInflater.from(context).inflate(R.layout.item,parent,false)
            return ViewHolder(view)
        }

        override fun getItemCount(): Int {
           return arrays.size
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val viewHolder=holder as ViewHolder
            viewHolder.textView.text=arrays[position]
        }

    }

    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        val textView=itemView.findViewById<TextView>(R.id.mText)
    }




}
