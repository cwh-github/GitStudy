package com.example.cwh_pc.rxjava2study

import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.KeyEvent
import android.widget.EditText
import com.jakewharton.rxbinding2.view.RxView
import com.jakewharton.rxbinding2.widget.RxTextView
import com.jakewharton.rxbinding2.widget.TextViewEditorActionEvent
import com.jakewharton.rxbinding2.widget.TextViewTextChangeEvent
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.internal.operators.completable.CompletableDisposeOn
import kotlinx.android.synthetic.main.activity_rx_binding.*
import org.jetbrains.anko.toast
import java.util.concurrent.TimeUnit



//RxBinding  RxBinding中的主要的Rx的操作有RxView(常规的View)
// RxTextView (具有Text属性的View)
// RxAdapterView  用于操作list中的某个item使用，参数为list整体(其实这里可以通过在Adapter中用RxView和RxTextView
// 来操作，一样可以实现)
// RxCompundButton (button的一种，用于来说明button是否被check或状态的改变)
class RxBindingActivity : AppCompatActivity() {
    lateinit var completale: CompositeDisposable
    lateinit var mEtText:EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rx_binding)
        completale= CompositeDisposable()
        mEtText=findViewById(R.id.mEtText)
        //textChange()
        //textChangeStart()
        //beforeTextChange()
        editorActions()
    }

    override fun onDestroy() {
        super.onDestroy()
        completale.clear()
    }

    fun log(msg:String){
        Log.d("RxBinding",msg)
    }

    //RxBinding 中的方法，监听Text的改变，这里只会返回改变后的字符串
    //注意，监听text变化的线程不是主线程
    fun textChange(){
      completale.add( RxTextView.textChanges(mEtText)
               .debounce(1,TimeUnit.SECONDS)
               .filter {
                   !TextUtils.isEmpty(it)
               }.observeOn(AndroidSchedulers.mainThread()).
                       subscribe {
                   toast("改变后的Text是$it")
               })
    }

    fun textChangeStart(){
        completale.add(RxTextView.textChangeEvents(mEtText)
                .debounce(1,TimeUnit.SECONDS)
                .filter {
                    log("start is ${it.start()}")
                    log("before is ${it.before()}")
                    log("Text is ${it.text()}")
                    !TextUtils.isEmpty(it.text())
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe()
        )

    }

    //RxBinding Text发生变化前产生的事件
    fun beforeTextChange(){
        completale.add(RxTextView.beforeTextChangeEvents(mEtText)
                .subscribe {
                    toast("Text 发生变化前调用，此时的text是${it.text()}")
                }
        )
    }

    fun afterTextChange(){
        completale.add(RxTextView.afterTextChangeEvents(mEtText)
                .subscribe {
                    toast("Text 发生变化后调用，此时的text是")
                }
            )
    }

    //RxBinding 监听EditText在编辑时的变化
    fun editorActions(){
        completale.add(RxTextView.editorActions(mEtText)
                .subscribe {
                    toast("输入完成，点击回车时调用")
                }
        )

        completale.add(RxTextView.editorActionEvents(mEtText)
                .subscribe {
                    val keyEvent=it.keyEvent()
                    if(keyEvent!!.keyCode==KeyEvent.KEYCODE_ENTER && keyEvent!!.action==KeyEvent.ACTION_UP){
                        toast("此时点击输入完成，点击回车 text is${it.view().text}")
                    }

                }
        )
    }

    fun editOpe(){
        completale.add(RxTextView.editorActions(mEtText)
                .subscribe { integer ->
                    RxTextView.text(mEtText).accept("LeiHolmes")
                    RxTextView.hint(mEtText).accept("请输入姓名")
                    RxTextView.color(mEtText).accept(Color.parseColor("#00ff00"))
                })
    }


}
