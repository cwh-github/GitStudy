package com.example.cwh_pc.rxjava2study

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_event_bus_study.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.jetbrains.anko.toast

class EventBusStudyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_bus_study)
        EventBus.getDefault().register(this)
        EventBus.getDefault().post(Message("EventBus Test Msg"))
        mBtnRxBinding.setOnClickListener {
            startActivity(Intent(this@EventBusStudyActivity,RxBindingActivity::class.java))
        }

        mBtnRxBus.setOnClickListener{
            RxBus.newInstance().post(Message("RxBus Send Msg"))
        }

        mBtnRxBusThread.setOnClickListener {
            Thread{
                RxBus.newInstance().post(Message("RxBus Send Msg On Thread"))
                RxBus.newInstance().post("RxBus Send Msg On Thread String")
            }.start()
        }

        mBtnRecyler.setOnClickListener{
            startActivity(Intent(this@EventBusStudyActivity,RecylerViewActivity::class.java))
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun reciveMsg(msg:Message){
        toast("${msg.msg}")
    }

    //对于注册的粘性事件，只有粘性的方法可以接收到，但是对于非粘性的
    // 方法，其发送的数据类型与粘性的一样时，粘性方法也可以接受到
    @Subscribe(threadMode = ThreadMode.MAIN,sticky = true)
    fun reciveSticky(msg:Message){
        mTvStick.text=msg.msg
    }

    @Subscribe
    fun reciverMsg(msg:Message){
        mTvEventBus.text=msg.msg
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }
}
