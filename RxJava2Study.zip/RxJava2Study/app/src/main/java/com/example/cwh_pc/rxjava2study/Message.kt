package com.example.cwh_pc.rxjava2study

data class Message(var msg:String)