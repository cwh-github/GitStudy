package com.example.cwh_pc.rxjava2study

import android.content.Intent
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import io.reactivex.*
import io.reactivex.Observable
import io.reactivex.Observer
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.exceptions.Exceptions
import io.reactivex.functions.BiFunction
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.AsyncSubject
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.ReplaySubject
import kotlinx.android.synthetic.main.activity_main.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.jetbrains.anko.toast
import org.reactivestreams.Subscriber
import org.reactivestreams.Subscription
import java.io.FileReader
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        dropBtnClick()
        //EventBus.getDefault().register(this)
        //easyObserver()
        //easyObserver1()
        //threadCheck()
        //rxJavaMap()
        //flatMap()
        //concatMap()
        //zip()
        //zipTest()
        //backPressure()
        //maxBackPressure()
        //backPressureStrategy()
        //interval()
        //requestSize()
        //requestSizeOnThread()
        //readFileRequest()
        //bufferOpe()
        //concatOpe()
        //disDiff()
        //defineDistinct()
        //filterOpe()
        //timerOpe()
        //intervalOpe()
        //doOnNextOpe()
        //skipOpe()
        //takeOpe()
        //justOpe()
        //singleOpe()
        //debounceOpe()
        //deferOpe()
        //lastOpe()
        //reduceOpe()
        //scanOpe()
        //windowOPe()
        //mergeOpe()
        //publicshSubjectOpe()
        asyncSubjectOpe()
        //behaviorSubjectOpe()
        //completableOpe()
        //throttleOpe()
        //replayOpe()
        //switchMapOpe()
        //mergeOnErrorOpe()
        addFragment()
        //retryWhenOpe()
        mBtnEventBus.setOnClickListener {
            EventBus.getDefault().postSticky(Message("发送粘性事件"))
            startActivity(Intent(this@MainActivity,EventBusStudyActivity::class.java))
        }

        rxBusOpe()
        rxBusBySelf()

        constrain.setOnClickListener {
            startActivity(Intent(this@MainActivity,AnimationActivity::class.java))
        }


    }

    @Subscribe
    fun reciveMsg(msg:Message){
        toast("${msg.msg}")
    }

    override fun onStop() {
        super.onStop()
        //EventBus.getDefault().removeAllStickyEvents()
        //EventBus.getDefault().unregister(this)
    }

    fun addFragment(){
        val fragmentManager= fragmentManager
        val fragment=LifeCycleFragment()
        fragmentManager.beginTransaction().add(fragment,fragment.toString()).commit()
    }

    override fun onDestroy() {
        super.onDestroy()
        if(disposable!=null && !disposable!!.isDisposed){
            disposable?.dispose()
        }
        EventBus.getDefault().removeAllStickyEvents()
        //EventBus.getDefault().unregister(this)

        RxBus.newInstance().removeDisposable(this)

    }

    fun log(msg: String) {
        Log.d("RxJava2", msg)
    }


    //基础创建事件流，RxJava2

    fun easyObserver() {
        val observable = Observable.create(ObservableOnSubscribe<Int> {
            it.onNext(1)
            it.onNext(2)
            it.onNext(3)
            //调用才会触发
            //it.onError( Throwable("Make by Author"))
            it.onComplete()
        })

        val observer = object : Observer<Int> {
            override fun onComplete() {
                log("onComplete")
            }

            override fun onSubscribe(d: Disposable) {
                log("onSubscribe")
            }

            override fun onNext(t: Int) {
                log("$t")
            }

            override fun onError(e: Throwable) {
                log("error is ${e.message}")
            }

        }
        //事件发送者与订阅者绑定
        observable.subscribe(observer)
    }

    fun easyObserver1() {
        Observable.create(ObservableOnSubscribe<Int> {

            //it 为事件发送者
            it.onNext(1)
            it.onNext(2)
            it.onNext(3)
            it.onComplete()

        }).subscribe(object : Observer<Int> {
            var disposable: Disposable? = null
            override fun onComplete() {
                log("onComplete")
            }

            override fun onSubscribe(d: Disposable) {
                log("onSubscribe")
                disposable = d
            }

            override fun onNext(t: Int) {
                log("$t")
                if (t == 2) {
                    disposable?.dispose()
                }
            }

            override fun onError(e: Throwable) {
                log("error is ${e.message}")
            }
        })
    }

    //线程的切换
    fun threadCheck() {
        val observable = Observable.create(ObservableOnSubscribe<Int> {
            log("observable thread is : ${Thread.currentThread().name}")
            it.onNext(1)
            it.onNext(2)
            it.onNext(3)
            it.onComplete()
        })

        val observer = object : Observer<Int> {
            override fun onComplete() {
                log("onComplete")
            }

            override fun onSubscribe(d: Disposable) {
                log("onSubscribe")
            }

            override fun onNext(t: Int) {
                log("OnNext Thread is ${Thread.currentThread().name}")
                log("$t")
            }

            override fun onError(e: Throwable) {
                log("error is ${e.message}")
            }

        }
        //通过RxJava2操作符切换线程
        observable.subscribeOn(Schedulers.newThread())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnNext {
                    log("do OnNext value is $it,current Thread is ${Thread.currentThread().name}")
                }
                .observeOn(Schedulers.io())
                .doOnNext {
                    log("do OnNext value is $it,current Thread is ${Thread.currentThread().name}")
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(observer)

    }

    //RxJava2 Map 操作  将上游发送的数据进行转换，接着发送到下游
    fun rxJavaMap() {
        Observable.create(ObservableOnSubscribe<Int> {

            it.onNext(1)
            it.onNext(2)
            it.onNext(3)
            it.onComplete()

        })
                .map {
                    "map to String value is $it"
                }
                .subscribe {
                    log(it)
                }

    }

    //RxJava2 flatMap 操作，将上游发送的数据，每个数据对应一个observable，将他们转换为其他的observables，
    //其中一个observable可能对应多个转换后的observable，最后将所有的observables合并在一起，作为一个无序的发送出去
    fun flatMap(){
        Observable.create(ObservableOnSubscribe<Int> {

            it.onNext(1)
            it.onNext(2)
            it.onNext(3)
            it.onComplete()

        }).flatMap {
            val list=ArrayList<String>()
            for(i in 0 until 3){
                list.add("value is $it")
            }
            Observable.fromIterable(list).delay(500,TimeUnit.MILLISECONDS)
        }.subscribe {
            log("flatmap value is $it")
        }
    }

    //concatMap 类似于flatmap，但是相对于flatmap，它是有序的
    fun concatMap(){
        Observable.create(ObservableOnSubscribe<Int> {

            it.onNext(1)
            it.onNext(2)
            it.onNext(3)
            it.onComplete()

        }).concatMap {
            val list=ArrayList<String>()
            for(i in 0 .. 3){
                log("$i")
                list.add("value is $i")
            }
            Observable.fromIterable(list)
        }.subscribe {
            log("flatmap value is $it")
        }
    }


    //RxJava2 zip 操作符   将两个observable经过一个函数，合成为一个observable发射出去，让后进行处理
    //其中会按顺序来进行合并，并且以较少事件源的发射结束作为结束,此时多的那个所在的线程会自动被结束掉
    fun zip(){
        val observable1=Observable.create(ObservableOnSubscribe <Int>{
            log("emitter 1")
            it.onNext(1)
            Thread.sleep(1000)
            log("emitter 2")
            it.onNext(2)
            Thread.sleep(1000)
            log("emitter 3")
            it.onNext(3)
            Thread.sleep(1000)
            log("emitter 4")
            it.onNext(4)
            log("Int Complete")
            it.onComplete()
        }).subscribeOn(Schedulers.io())

        val observable2=Observable.create(ObservableOnSubscribe<String> {
            log("emitter A")
            it.onNext("A")
            Thread.sleep(1000)
            log("emitter B")
            it.onNext("B")
            Thread.sleep(1000)
            log("emitter C")
            it.onNext("C")
            Thread.sleep(1000)
            log("String Complete")
            it.onComplete()
        }).subscribeOn(Schedulers.io())

        Observable.zip(observable1,observable2, BiFunction<Int, String,  String> { t1, t2 ->
            "$t1$t2"
        }).subscribe {
            log("zip value is $it")
        }


    }

    fun zipTest(){
        val observable1=Observable.create(ObservableOnSubscribe <Int>{
            for(i in 0..Int.MAX_VALUE){
                it.onNext(i)
                Thread.sleep(2000)
            }
        }).subscribeOn(Schedulers.io())

        val observable2=Observable.create(ObservableOnSubscribe<String> {
            log("emitter A")
            it.onNext("A")
            Thread.sleep(1000)
            log("emitter B")
            it.onNext("B")
            Thread.sleep(1000)
            log("emitter C")
            it.onNext("C")
            Thread.sleep(1000)
            log("String Complete")
            it.onComplete()
        }).subscribeOn(Schedulers.io())

        Observable.zip(observable1,observable2, BiFunction<Int, String,  String> { t1, t2 ->
            "$t1$t2"
        }).subscribe {
            log("zip value is $it")
        }
    }

    //RxJava2 Flowable 背压式的方式处理事件的发送速度和处理速度不均衡的问题
    fun backPressure(){
        val flowable=Flowable.create(FlowableOnSubscribe <Int>{
            log("emitter 1")
            it.onNext(1)

            log("emitter 2")
            it.onNext(2)

            log("emitter 3")
            it.onNext(3)

            log("emitter 4")
            it.onNext(4)

            log("Int Complete")
            it.onComplete()
        },BackpressureStrategy.ERROR).subscribeOn(Schedulers.io())

        val subscriber=object :Subscriber<Int>{
            override fun onSubscribe(s: Subscription?) {
                log("onSubscribe")
                //s?.request(Long.MAX_VALUE)
            }

            override fun onComplete() {
                log("onComplete")
            }

            override fun onNext(t: Int) {
                log(" onNext $t")
            }

            override fun onError(e: Throwable) {
                log("error is $e")
            }

        }

        flowable.observeOn(AndroidSchedulers.mainThread()).subscribe(subscriber)
    }

    fun maxBackPressure(){
        //Flowable 维持一个大小为128的缓存池，切换线程后才可以使用，在正常的一个线程中会报MissBackPressureException
        val flowable=Flowable.create(FlowableOnSubscribe <Int>{
            for(i in 0 until 128){
                log("emitter $i")
                it.onNext(i)
            }
            it.onComplete()
        },BackpressureStrategy.ERROR).subscribeOn(Schedulers.io())

        val subscriber=object :Subscriber<Int>{
            override fun onSubscribe(s: Subscription?) {
                log("onSubscribe")
               // s?.request(300)
            }

            override fun onComplete() {
                log("onComplete")
            }

            override fun onNext(t: Int) {
                Thread.sleep(3000)
                log(" onNext $t")
            }

            override fun onError(e: Throwable) {
                log("error is $e")
            }

        }

        flowable.observeOn(AndroidSchedulers.mainThread()).subscribe(subscriber)
    }
    var subscription:Subscription?=null
    fun backPressureStrategy(){
        //对于下游使用了request，但是上游没有限制好发送，还是会造成发送与接收的不均衡，所以需要一种
        //策略来处理这种上游的发送
        val flowable=Flowable.create(FlowableOnSubscribe <Int>{
            for(i in 0 until 10000){
                it.onNext(i)
            }
            it.onComplete()
        },BackpressureStrategy.LATEST).subscribeOn(Schedulers.io())

        val subscriber=object :Subscriber<Int>{
            override fun onSubscribe(s: Subscription?) {
                log("onSubscribe")
                //会来限制缓存池的大小
                s?.request(128)
                subscription=s
            }

            override fun onComplete() {
                log("onComplete")
            }

            override fun onNext(t: Int) {
                //Thread.sleep(3000)
                log(" onNext $t")
            }

            override fun onError(e: Throwable) {
                log("error is $e")
            }

        }

        flowable.observeOn(AndroidSchedulers.mainThread()).subscribe(subscriber)
    }

    fun dropBtnClick(){
        dropBtn.setOnClickListener {
            subscription?.request(95)
        }
    }

    fun interval(){
        Flowable.interval(1,TimeUnit.MICROSECONDS)
                .onBackpressureDrop()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object :Subscriber<Long>{
                    override fun onNext(t: Long?) {
                        log(" onNext $t")
                        Thread.sleep(1000)
                    }

                    override fun onSubscribe(s: Subscription?) {
                        log("onSubscribe")
                        //会来限制缓存池的大小
                        s?.request(Long.MAX_VALUE)
                        subscription=s
                    }

                    override fun onComplete() {
                        log("onComplete")
                    }


                    override fun onError(e: Throwable) {
                        log("error is $e")
                    }

                })
    }


    fun requestSize(){
        Flowable.create(FlowableOnSubscribe <Int>{
            for(i in 0 until 200){
                it.onNext(i)
                log("emitter value $i, and request is ${it.requested()}")
            }


        },BackpressureStrategy.ERROR)
                .subscribe(object :Subscriber<Int>{
                    override fun onComplete() {
                        log("onComplete")
                    }

                    override fun onSubscribe(s: Subscription?) {
                        log("onSubscribe")
                        s?.request(128)
                        subscription=s
                    }

                    override fun onNext(t: Int?) {
                        log("OnNext value is $t")
                    }

                    override fun onError(t: Throwable?) {
                        log("on Error is $t")
                    }

                })
    }

    fun requestSizeOnThread(){
        Flowable.create(FlowableOnSubscribe <Int>{
            var flag=false
            for(i in 0 until 1000){
                while(it.requested()==0L){
                    if(!flag){
                        log("No Request Count,can`t emmiter value")
                        flag=true
                    }
                }
                it.onNext(i)
                log("emitter value $i, and request is ${it.requested()}")
            }


        },BackpressureStrategy.ERROR)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object :Subscriber<Int>{
                    override fun onComplete() {
                        log("onComplete")
                    }

                    override fun onSubscribe(s: Subscription?) {
                        log("onSubscribe")
                        subscription=s
                    }

                    override fun onNext(t: Int?) {
                        log("OnNext value is $t")
                    }

                    override fun onError(t: Throwable?) {
                        log("on Error is $t")
                    }

                })
    }

    fun readFileRequest(){
        Flowable.create(FlowableOnSubscribe <String>{
            emmiter->
            try {
                val reader=FileReader("build.gradle")
                reader.forEachLine {
                    while (it!=null && !emmiter.isCancelled){
                        while(emmiter.requested()==0L){
                            if(emmiter.isCancelled){
                                break
                            }
                        }
                        emmiter.onNext(it)
                    }
                }
                emmiter.onComplete()
            }catch (e:Exception){
                emmiter.onError(e)
            }

        },BackpressureStrategy.ERROR)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object :Subscriber<String>{
                    override fun onComplete() {
                        log("OnComplete")
                    }

                    override fun onSubscribe(s: Subscription?) {
                        subscription=s
                        s?.request(1)
                    }

                    override fun onNext(t: String?) {
                        Thread.sleep(1000)
                        log("$t")
                        subscription?.request(1)
                    }

                    override fun onError(t: Throwable?) {
                        log("$t")
                    }

                })
    }

    fun bufferOpe(){
        //count指明每个buffer的最大个数，skip指明每个buffer的起始相当于前一个起始的间隔值
        Observable.just(1,2,3,4,5)
                .buffer(4,1)
                .subscribe {
                    log("buffer size is ${it.size}")
                    it.forEach {
                        log("value is $it")
                    }
                }
    }

    //RxJava2 concat操作符，是将两个observable合并为一个observable，不会生成一个新的，只是将其的参数合并为一个
    //不同数据类型也可以合并
    fun concatOpe(){
        Observable.concat(Observable.just(1,2,3),Observable.just("4","5","6"))
                .subscribe {
                    log("concat value is $it")
                }
    }

    fun disDiff(){
        Observable.just(1,2,2,3,5,66,7,6,5,6)
                .distinct{
                  if(it>=6){
                        it
                    }else{
                       0
                   }
                }
                .subscribe {
                    log("distinct value is $it")
                }
    }

    //RxJava2 自定义去重，其中distinct的函数定义去重的字段
    fun defineDistinct(){
        val student1 = Student("LHD", 90)
        val student2 = Student("LHD1", 80)
        val student3 = Student("LHD2", 70)
        val student4 = Student("LHD3", 96)
        val student5 = Student("LHD5", 70)
        val student6 = Student("LHD6", 70)

        Observable.just(student1,student2,student3,student4,student5,student6)
                .distinct {
                    it.age
                }.subscribe {
                    log("Student is $it")
                }


    }

    //RxJava2 filter 根据条件筛选，返回true即为所需要的值
    fun filterOpe(){
        Observable.just(1,2,3,4,5,6,7,8,9)
                .filter {
                    it>3
                }.subscribe {
                    log("filter value is $it")
                }
    }

    //Rxjava2 计时器 指定时间后延迟执行
    fun timerOpe(){
        Observable.timer(2,TimeUnit.SECONDS)
                .subscribeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe {
                    log("Current Thread is ${Thread.currentThread().name}")
                    log("Subscribe time is ${System.currentTimeMillis()}")
                }.observeOn(AndroidSchedulers.mainThread())
                .subscribe {
                    log("Do Timer time is ${System.currentTimeMillis()}")
                }
    }

    var disposable:Disposable?=null
    //RxJava2 interval 指定间隔时间操作相关函数  ，其中可以有参数指定第一次操作的延迟时间
    //由于开了一个线程一直在循环，所以需要在结束时，停止该线程
    fun intervalOpe(){
        disposable=Observable.interval(1,2,TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe {
                    log("interval time is ${System.currentTimeMillis()}")
                }
    }

    //RxJava2 doOnNext 在让订阅者接受事件前，做点其他的事
    fun doOnNextOpe(){
        Observable.just(1,2,3,4,5,6)
                .subscribeOn(Schedulers.io())
                .doOnNext {
                    log("do onNext Thread is ${Thread.currentThread().name}")
                    log("do on Next value is $it")
                }.observeOn(AndroidSchedulers.mainThread())
                .subscribe{
                    log("do On Next subcribe value is $it")
                }

    }

    //Rxjava2 跳过指定步数   其中是从第一个参数开始跳过指定步数，到获取的结构超过范围为止
    fun skipOpe(){
        Observable.just(1,2,3,4,5)
                .skip(3)
                .subscribe {
                    log("Skip value is $it")
                    //result is  4,5
                }
    }

    //RxJava2 take获取指定个数的参数，后面的都会除去，如果超过参数，则会获取所有结果
    fun takeOpe(){
        Observable.just(1,2,3,4,5)
                .take(6)
                .subscribe {
                    log("take result is $it")
                }
    }

    //RxJava2 just操作符，遍历参数，执行onNext方法
    fun justOpe(){
        Observable.just(1,2,3,4,5)
                .subscribe {
                    log("just value is $it")
                }
    }


    //RxJava2 Single 只会接受一个参数，且observer会只会调用onSuccess或OnError
    fun singleOpe(){
        Single.just(Random().nextInt())
                .subscribe(object :SingleObserver<Int>{
                    override fun onSuccess(t: Int) {
                        log("OnSuccess $t")
                    }

                    override fun onSubscribe(d: Disposable) {
                        log("Single onSubscribe")
                    }

                    override fun onError(e: Throwable) {
                        log("Single OnError")
                    }

                })
    }

    //RxJava2 除去发送频率过快的项，频率大于500(根据两次发送间的间隔时间决定是否除去前一个发送)，则发送出去

    //也可解释为，发送第一个消息之后，会等待一段时间，在这个指定的时间内，没有其他的事件发出，则会发送这个事件
    //否则放弃这个事件，开始下一个事件的记时
    fun debounceOpe(){
        Observable.create(ObservableOnSubscribe <Int>{
            it.onNext(1)
            Thread.sleep(100)
            it.onNext(2)
            Thread.sleep(400)
            it.onNext(3)
            Thread.sleep(500)
            it.onNext(4)
            Thread.sleep(600)
            it.onNext(5)
            it.onComplete()


        }).debounce(500,TimeUnit.MILLISECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe {
            log("debounce value is $it")
                    //result is 4,5
        }
    }

    //RxJava2 在订阅时，执行defer里的方法，生成observer,用于被订阅
    fun deferOpe(){
        Observable.defer {
            Observable.just(1,2,3)
        }.subscribe {
            log("defer value is $it")
        }

    }

    //RxJava2  last操作符，去除项目发出的最后一个事件或者是满足条件的最后一事件
    //形成一个single的被观察者
    fun lastOpe(){
        Observable.just(1,2,3)
                .last(4)
                .subscribe (object :SingleObserver<Int>{
                    override fun onSuccess(t: Int) {
                        log("OnSuccess $t")
                    }

                    override fun onSubscribe(d: Disposable) {
                        log("Single onSubscribe")
                    }

                    override fun onError(e: Throwable) {
                        log("Single OnError")
                    }

                })
    }

    //RxJava2 merge操作符有点类似于concat操作符，也是合并事件，但是concat是顺序的合并，merge
    //并不是顺序的合并，它会随机的合并
    fun mergeOpe(){
        Observable.merge(Observable.just(1,2,3),Observable.just(4,5,6))
                .subscribe ({
                    log("merge value is $it")
                },{

                },{
                    log("OnComplete")
                })

    }

    //RxJava2  merge 操作，当其中一个发生onError时，其他merge操作不会再继续下去，会直接执行onError操作
    fun mergeOnErrorOpe(){
        val observable=Observable.create(ObservableOnSubscribe <Int>{
            it.onNext(1)
            it.onNext(2)
            it.onError(Throwable("Merge OnError"))
        }).onErrorResumeNext(Observable.empty())

        val observable1=Observable.create(ObservableOnSubscribe <Int>{
            it.onNext(3)
            it.onNext(4)
            it.onComplete()
        })

        Observable.merge(observable,observable1)
                .subscribe({
                    log("merge value is$it")
                },{
                    log("Error msg is $it")
                },{
                    log("OnComplete")
                })
    }

    //RxJava2 reduce操作符，将observable的事件按照reduce的转换，转换后的值
    //作为一个新的参数继续转换，直到转换完成
    fun reduceOpe(){
        Observable.just(1,2,3,4)
                .reduce { t1: Int, t2: Int ->
                    t1+t2
                }.subscribe {
                    log("reduce value is $it")
                }
        //1+2的结果做为新的参数，继续进行reduce函数
    }


    //RxJava2 scan与reduce类似，只不过，scan会对过程的事件发送出来，且其有一个初始值0
    fun scanOpe(){
        Observable.just(1,2,3,4)
                .scan { t1: Int, t2: Int ->
                    t1+t2
                }.subscribe {
                    log("Scan Value is $it")
                }
    }

    //RxJava2 window操作符，将部分事件根据window函数，划分为多个observable在subscribe时返回
    //这里会返回5个observable
    fun windowOPe(){
        Observable.interval(1,TimeUnit.SECONDS)
                .take(15)
                .window(3,TimeUnit.SECONDS)
                .subscribe {
                    log("Make a Window Observable")
                    it.subscribe {
                        log("OnNext value is $it")
                    }
                }
    }
    //RxJava2 PublicSubject  当执行OnNext发送事件时，会发送给每一个的subscriber，若执行了onComplete后，则不会发送，但是后绑定的
    //也会接收到onComplete
    fun publicshSubjectOpe(){
        val publishSubject=PublishSubject.create<Int>()
        publishSubject.subscribe( {
            log("First Subscriber ")
            log("First Value is $it")
        },{

        },{
            log("First OnComplete")
        })
        publishSubject.onNext(1)
        publishSubject.onNext(2)
        //publishSubject.onComplete()

        publishSubject.subscribe( {
            log("Second Subscriber ")
            log("Second Value is $it")
        },{

        },{
            log("Second OnComplete")
        })

        publishSubject.onNext(4)
        publishSubject.onNext(5)
        publishSubject.onNext(6)
        publishSubject.onComplete()
    }


    //RxJava2 AsyncSubject 操作符，有点类似于PublicSubject，但是其在调用onComplete之前，除了subscribe()方法外，其他操作都会缓存
    //在调用onComplete后，只有最后一个onNext会生效,由于是async的，在后面绑定的也会执行最后一个onNext()
    fun asyncSubjectOpe(){
        val asyncSubject=AsyncSubject.create<Int>()
        asyncSubject.subscribe ({
            log("First Subscriber ")
            log("First Value is $it")
        },{

        },{
            log("First OnComplete")
        })


        asyncSubject.onNext(1)
        asyncSubject.onNext(2)
        asyncSubject.onNext(3)
        asyncSubject.onComplete()

        asyncSubject.subscribe({
            log("Second Subscriber ")
            log("Second Value is $it")
        },{

        },{
            log("Second OnComplete")
        })

        asyncSubject.onNext(4)
        asyncSubject.onNext(5)
        //asyncSubject.onComplete()
    }

    //RxJava2 BehaviorSubject与PublicerSubject一样，会报OnNext发射给所有的订阅者，但是在会缓存最后一次OnNext，在下一次subscriber时，
    // 会将缓存传递给下一个
    //订阅者，但是在onComplete后，不会再传递给下一个订阅者
    fun behaviorSubjectOpe(){
        val behaviorSubject=BehaviorSubject.create<Int>()
        behaviorSubject.subscribe({
            log("First Subscriber ")
            log("First Value is $it")
        },{

        },{
            log("First OnComplete")
        })

        behaviorSubject.onNext(1)
        behaviorSubject.onNext(2)
        behaviorSubject.onNext(3)
        behaviorSubject.onComplete()

        behaviorSubject.subscribe({
            log("Second Subscriber ")
            log("Second Value is $it")
        },{

        },{
            log("Second OnComplete")
        })

        behaviorSubject.onNext(4)
        behaviorSubject.onNext(5)
        //behaviorSubject.onComplete()
    }

    //RxJava2 Completable只关注结果，不关注过程，所以只有onComplete和onError
    fun completableOpe(){
        Completable.timer(1,TimeUnit.SECONDS)
                .subscribe(object :CompletableObserver{
                    override fun onSubscribe(d: Disposable) {
                        log("Subscribe")
                    }

                    override fun onError(e: Throwable) {
                        log("Completable OnError")
                    }

                    override fun onComplete() {
                        log("Completable onComplete")
                    }

                })
    }


    //RxJava2 throttleFirst 或者throttleLast指定时间段内只拿第一个或最后一个事件发射出去
    fun throttleOpe(){
        Observable.create(ObservableOnSubscribe <Int>{
            it.onNext(1)
            Thread.sleep(200)
            it.onNext(2)
            Thread.sleep(100)
            it.onNext(3)
            Thread.sleep(1200)
            it.onNext(4)

        }).throttleFirst(1000,TimeUnit.MILLISECONDS)
                .subscribe {
            log("throttleFirts value is $it")
        }

        Observable.create(ObservableOnSubscribe <Int>{
            it.onNext(1)
            Thread.sleep(200)
            it.onNext(2)
            Thread.sleep(100)
            it.onNext(3)
            Thread.sleep(1200)
            it.onNext(4)

        }).throttleLast(1000,TimeUnit.MILLISECONDS)
                .subscribe {
                    log("throttleLast value is $it")
                }
    }


    //RxJava2 ReplaySubject，不管何时注册的观察者，都会接收到全部的发射出去的事件
    fun replayOpe(){
        val replaySubject=ReplaySubject.create<Int>()
        replaySubject.publish().subscribe{
            log("First replay value is $it")
        }

        replaySubject.onNext(1)
        replaySubject.onNext(2)
        replaySubject.onNext(3)
        replaySubject.onComplete()

        replaySubject.subscribe{
            log("Second replay value is $it")
        }

        Observable.create(ObservableOnSubscribe<Int>{
            it.onNext(1)
            try {
                Thread.sleep(500)
            } catch (e:InterruptedException ) {
                throw Exceptions.propagate(e)
            }
            it.onNext(2)
            try {
                Thread.sleep(500)
            } catch (e:InterruptedException ) {
                throw Exceptions.propagate(e)
            }

            it.onNext(3)
            try {
                Thread.sleep(1000)    
            } catch (e:InterruptedException ) {
                throw Exceptions.propagate(e)
            }
            it.onNext(4)
            it.onNext(5)
            it.onComplete()

        }).debounce(999, TimeUnit.MILLISECONDS)//或者为throttleWithTimeout(1000, TimeUnit.MILLISECONDS)
        .subscribe{
            log("result is $it")
        } //结果为3,5
    }

    //RxJava2 该操作符在同一线程中的用法与contactMap一样，当每个生成的Observable在不同线程时，才会
    //在新生成的一个observable发送消息时，前一个被取消掉
    fun switchMapOpe(){
        Observable.create(ObservableOnSubscribe<Int> {
            it.onNext(1)
            //Thread.sleep(250)
            //Thread.sleep(250)
            it.onNext(2)
            it.onComplete()
        })
                //.debounce(200,TimeUnit.MILLISECONDS)
                .switchMap {
                    Observable.create(ObservableOnSubscribe<Int> {
                        it.onNext(3)
                        //Thread.sleep(300)
                        it.onNext(4)
                    }).subscribeOn(Schedulers.io())
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe {
                    log("Switch Map value is$it")
                }
        //3 3 4
    }

    //RxJava2 retryWhen需要终止时，通过empty或error都可以
    fun retryWhenOpe(){
         Observable.just(1,2,3,4,5,6,7,8,9,0).map{
             log("emmiter value is $it")
            when(it){
                5->throw RuntimeException("no retry")
                8->throw RuntimeException("no retry")
                else->it
            }
        }.retryWhen {
                it.flatMap {
                    log("msg is ${it.message!!}")
                    return@flatMap when {
                        it.message=="retry" ->Observable.just("0")
                        it.message=="no retry" -> Observable.empty()
                        else -> {
                            log("Come in ")
                            Observable.empty()
                        }
                    }
                }
            }.subscribe( {
                log("retry value is $it")
            },{
                log("error is ${it.message}")
            },{
                log("onComplete")
            })
    }

    /**
     *用默认RxBus方式处理事件
     */
    fun rxBusOpe(){
       val disposable= RxBus.newInstance().doSubscribe(Message::class.java,{
            log("RxBus Recive Msg is $it")
            toast("RxBus Recive Msg is $it")
        },{
            log("RxBus Recive error is ${it.message}")
        },{
            log("OnComplete")
        })

        RxBus.newInstance().addDisposable(this,disposable)
    }

    /**
     * 自定义的方式处理RxBus发送的事件
     */
    fun rxBusBySelf(){
        val disposable=RxBus.newInstance().toObservable(String::class.java)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe ({
                    log("RxBus BySelf Msg is $it")
                    toast("RxBus BySelf Msg is $it")
                },{
                    log("RxBus BySelf error is ${it.message}")
                },{
                    log("OnComplete")
                })
        RxBus.newInstance().addDisposable(this,disposable)
    }



}
