package com.example.cwh_pc.rxjava2study

import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.constraint.ConstraintSet
import android.transition.TransitionManager
import android.util.Log
import android.view.MotionEvent
import kotlinx.android.synthetic.main.activity_animation.*

class AnimationActivity : AppCompatActivity() {

    var isFirst: Boolean = true
    lateinit var constraintSet1: ConstraintSet
    lateinit var constraintSet2: ConstraintSet
    @RequiresApi(Build.VERSION_CODES.KITKAT)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_animation)
        val constrain = findViewById<ConstraintLayout>(R.id.constrain)
        constraintSet1 = ConstraintSet()
        constraintSet2 = ConstraintSet()
        constraintSet1.clone(constrain)
        constraintSet2.clone(this, R.layout.activity_animation1)
        animation.setOnClickListener {
            if (isFirst) {
                isFirst = false
                TransitionManager.beginDelayedTransition(constrain)
                constraintSet2.applyTo(constrain)
            } else {
                isFirst = true
                TransitionManager.beginDelayedTransition(constrain)
                constraintSet1.applyTo(constrain)
            }
        }

    }

    @RequiresApi(Build.VERSION_CODES.KITKAT)
    override fun onTouchEvent(event: MotionEvent?): Boolean {

        var start: Float = 0f
        var end = 0f
        when (event!!.action) {
            MotionEvent.ACTION_DOWN -> {
                start = event!!.rawY
                return super.onTouchEvent(event)
            }

            MotionEvent.ACTION_MOVE -> {
                end = event!!.rawY
                if (Math.abs(end - start) >= 20) {
                    Log.d("Touch","distance is 20s")
                    if ((end - start) > 0) {
                        TransitionManager.beginDelayedTransition(constrain)
                        constraintSet2.applyTo(constrain)
                    } else {
                        TransitionManager.beginDelayedTransition(constrain)
                        constraintSet1.applyTo(constrain)
                    }
                    return true
                }
            }

            MotionEvent.ACTION_UP -> {
                return super.onTouchEvent(event)
            }
        }

        return super.onTouchEvent(event)
    }
}
